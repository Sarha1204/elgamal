#!/usr/bin/env python
# -*- coding: utf-8 -*-


import codecs
from time import time
import os, argparse
parser = argparse.ArgumentParser()
import hashlib
import os
import numpy as np

#opciones

parser.add_argument("-rc4", help="Algoritmo de cifrado por Flujo", action="store_true")
parser.add_argument("-a", help="Despliega ayuda del algoritmo en particular", action="store_true")
parser.add_argument("-c", help="opcion para cifrar", action="store_true")
parser.add_argument("-d", help="opcion para descifrar", action="store_true")
parser.add_argument("-txt", type=str, help="nombre del archivo del texto a cifrar o descifrar", default=os.getcwd(), required=False)
parser.add_argument("-key", type=str, help="nombre del archivo que contiene la clave", default=os.getcwd(), required=False)
args=parser.parse_args()


if (args.rc4 == False and args.a == False) or (args.rc4 == True and args.c == False and args.d == False):

    print("""
        --------------------------------UNIVERSIDAD AUTONOMA DE OCCIDENTE-------------------------
        ----------------------------------Algoritmo de Cifrado de Flujo---------------------------
        |                                                                               |
    |                                                   |
    |   
        NOTA: CON EL SIGUIENTE COMANDO LE GENERA LOS DOS ARCHIVOS, EL CIFRADO Y DESCIFRADO.
            COMPROBAR SU INTEGRIDAD CON EL COMANDO MD5SUM EN LA TERMINAL DE COMANDOS.                                      
    |   

    |                                           |
    |  Comando:       python3 RC4.py -rc4 -c -txt <ArchivoEntrada> -key <ArchivoClave>    
    |                                                                               
    |      <opcion> :
              -c para cifrar el archivo <ArchivoEntrada>                    
    |        -rc4: para ejecutar el algoritmo.
            -txt: para llamar el archivo con el texto en claro.
            -key: para llamar el archivo que contiene la llave.                            
    |                                           |
    |      <ArchivoEntrada>: nombre del archivo de entrada                          
    |                                                   |
    |      <ArchivoClave>  : nombre del archivo que contiene la clave                   
    |                                           |
    |          |                                           |
    |  Elaborado por: Jose Mauricio Villota    jvillota77@gmail.com         |
    |                 Sarha Sophia  Sandoval   sarhasandoval@gmail.com  
    |   Docente: Ing. Siler Amador Donado
    |---------------------------------------------------------------------------------------|
        """)
if args.rc4== True and args.c == True:

    tiempo_inicial=time()
    
    MOD = 256

    #Algoritmo RSA
    def KSA(key):
        
        key_length = len(key)
        # se creal el vector "S"
        S = list(range(MOD))  # [0,1,2, ... , 255]
        j = 0
        for i in range(MOD):
            j = (j + S[i] + key[i % key_length]) % MOD
            S[i], S[j] = S[j], S[i]  # swap values

        return S

        #Alforitmo PRGA
    def PRGA(S):
        
        i = 0
        j = 0
        while True:
            i = (i + 1) % MOD
            j = (j + S[i]) % MOD

            S[i], S[j] = S[j], S[i]  # swap values
            K = S[(S[i] + S[j]) % MOD]
            yield K


    def get_keystream(key):
        ''' 
            Toma la clave de cifrado para obtener el flujo de claves utilizando PRGA
            El objeto de retorno es un generador.
        '''
        S = KSA(key)
        return PRGA(S)


    def encrypt_logic(key, text):
        ''' :key -> clave utilizada para cifrar
            :text -> valores del array
        '''
        # para la clave se utiliza lo siguiente:
        key = [ord(c) for c in key]
        # si la clave es en hexadecimal:
        # key = codecs.decode(key, 'hex_codec')
        # key = [c for c in key]
        keystream = get_keystream(key)

        res = []
        for c in text:
            val = ("%02X" % (c ^ next(keystream)))  # funcion para realizar xor
            res.append(val)
        return ''.join(res)


    def encrypt(key, plaintext):
        ''' :clave -> clave de cifrado utilizada para cifrar, como cadena hexadecimal
            : texto plano -> cadena de texto plano a cifrar
            
        '''
        plaintext = [ord(c) for c in plaintext]
        return encrypt_logic(key, plaintext)


    def decrypt(key, ciphertext):
        ''' :key -> encryption key used for encrypting, as hex string
            :ciphertext -> hex encoded ciphered text using RC4
        '''
        ciphertext = codecs.decode(ciphertext, 'hex_codec')
        res = encrypt_logic(key, ciphertext)
        return codecs.decode(res, 'hex_codec').decode('utf-8')


    def main():

        
        key=open(args.key,'r', encoding="ISO-8859-1")
        key=key.read()
        
        plaintext=open(args.txt,'r', encoding="ISO-8859-1")
        plaintext=plaintext.read()
        
        # encrypt the plaintext, using key and RC4 algorithm
        ciphertext = encrypt(key, plaintext)
        #print('plaintext:', plaintext)
        #print('ciphertext:', ciphertext)
        salida = args.txt
        punto = salida.index(".")
        salida = salida[0:punto] + ".cif"
        archivo = open(salida, "w", encoding="ISO-8859-1")
        archivo.write (ciphertext)
        
        #DESCIFRAR ARCHIVO
        decrypted = decrypt(key, ciphertext)
        #print('decrypted:', decrypted)
        salida = args.txt
        punto = salida.index(".")
        salida = salida[0:punto] + ".dec"
        archivo = open(salida, "w", encoding="ISO-8859-1")
        archivo.write (decrypted)
        """
        archivo = open('cifrado.dec','w' )
        archivo.write (decrypted)
        archivo.close()"""
        if plaintext == decrypted:
            print('\nArchivo cifrado correctamente')
        else:
            print('Error')

        # until next time folks !
        tiempo_final = time()
        tiempo_total = tiempo_final - tiempo_inicial
        print("tiempo total", tiempo_total) #indica el tiempo que se demora cifrando

    