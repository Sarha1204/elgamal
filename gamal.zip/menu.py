#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, argparse
from time import time
import numpy as np
import base64
import hashlib
parser = argparse.ArgumentParser()
# Opciones algoritmos.
parser.add_argument("-gama", help="Algoritmo de ElGamal", action="store_true")
parser.add_argument("-c", help="opcion para cifrar", action="store_true")
parser.add_argument("-g", help="opcion para cifrar", action="store_true")
parser.add_argument("-hash", help="opcion para cifrar", action="store_true")
parser.add_argument("-gm", help="opcion para cifrar", action="store_true")
parser.add_argument("-d", help="opcion para descifrar", action="store_true")
parser.add_argument("-b64", help="opcion para codificar", action="store_true")
parser.add_argument("-texto", type=str, help="nombre del archivo del texto a cifrar o descifrar", default=os.getcwd(), required=False)
parser.add_argument("-txtprimo", type=str, help="nombre del archivo que contiene el primo", default=os.getcwd(), required=False)
parser.add_argument("-txtgenerador", type=str, help="nombre del archivo que contiene el generador", default=os.getcwd(), required=False)
parser.add_argument("-txtpriva", type=str, help="nombre del archivo que contiene la llave privada de a", default=os.getcwd(), required=False)
parser.add_argument("-txtpublica", type=str, help="nombre del archivo que contiene la llave publica A", default=os.getcwd(), required=False)
parser.add_argument("-txtllaveb", type=str, help="nombre del arvhvo que contiene la llave privada de b", default=os.getcwd(), required=False)
parser.add_argument("-txty1", type=str, help="nombre del archivo que contiene y1", default=os.getcwd(), required=False)
parser.add_argument("-txty2", type=str, help="nombre del archivo que contiene y2", default=os.getcwd(), required=False)

args=parser.parse_args()


#Cifrado el gamal

if args.gama == True:
	
	print(""" 
	----------------------------------------------UAO-----------------------------------------------
	---------------------------------------Cifrado de Elgamal---------------------------------------			
	|											       |
	|											       |
	|   Sintaxis:										       |
	|	*para generar la llave publica:							       |
	|	  ./menu.py  -gama -c -texto (mensaje) -txtprimo (archivo) -txtgenerador (archivo)     |
  	|								                               |
	|	*para generar Y1 y Y2:								       |
	|	  ./menu.py -gama -g -txtpublica (archivo) -txtllaveb (archivo) 		       |
	|		-txtgenerador (archivo) -texto (mensaje) -txtprimo (archivo)                   |
	|   										               |
	|	*para desifrar:								               |
	|	  ./menu.py -gama -gm -txty1 (archivo) -txty2 (archivo) -txtprimo (archivo)            |
	|		-txtpriva (archivo)	               					       |	                               	
	|											       |  
	|	Elaborado por:								               |
	|											       |	
	|	 NOMBRE: JOSE MAURICIO VILLOTA PAZ				                       |
	|	 NOMBRE: SARHA SOPHIA SANDOVAL SANDOVAL				                       |
	|										               |
	------------------------------------------------------------------------------------------------	
	""")
		
		
if args.gama == True and args.c == True:


	tiempo_inicial = time()         # Funciòn de tiempo original.

	mensaje=open(args.texto,'r',encoding="ascii") # leer archivo que contiene el texto plano
	mensaje=mensaje.read()


	#mensaje = ""

	#codificar mensaje base64

	codi = mensaje.encode("utf-8")
	encoded = base64.b64encode(codi)
	Mcodi= encoded.decode("utf-8")

	#Mcodi = base64.b64decode(Mcodi)
	
	#Mcodi = Mcodi.decode("ISO-8859-1")

	#casci = mensaje.encode("ascii")

	#Mcodi=Mcodi.encode("ascii")	

	#print(Mcodi)


	
	# Calculo del hash

	filename = '/root/Downloads/' + args.texto
	hasher = hashlib.md5()
	with open(filename,"rb") as open_file:
		content = open_file.read()
		hasher.update(content)
	print ("Hash = ", hasher.hexdigest())

	
	# Leo el archivo que contiene la clave	

	primo=open(args.txtprimo,'r', encoding="ISO-8859-1") # leer archivo que contiene la clave
	primo=primo.read()
	primo=int(primo)
	

	#leo el archivo que contiene el generador

	generador=open(args.txtgenerador,'r', encoding="ISO-8859-1") # leer archivo que contiene la generador
	generador=generador.read()
	generador=int(generador)
	#generador=str(generador)


	#leo la llave privada de A

	calvea=open(args.txtpriva,'r', encoding="ISO-8859-1") # leer archivo que contiene la llave de a
	calvea=calvea.read()
	calvea=int(calvea)
	#calvea=str(calvea)

	msg_cifra = ""
	
	#Generamos la llave publica A

	llavepub=(generador**calvea)%primo
	llavepub=str(llavepub)

	#print (llavepub)

	#f = open ('llavepublica.txt',"w",)
	#f.write(str((llavepub)))
	#f.close()


	
	cripto = open("llavepublica.txt", "w", encoding="ISO-8859-1")
	cripto.write(llavepub)

	# funcion de calculo de tiempo final
	tiempo_final = time()
	tiempo_total = tiempo_final - tiempo_inicial   #Calculo el tiempo total de ejecucion
	print ("tiempo_total: ", tiempo_total)

	#ciframos el mensaje generando Y1 y Y2
if args.gama == True and args.g == True:

	tiempo_inicial = time()         # Funciòn de tiempo original.

	#leemos los archivos
	
	
	llaveb=open(args.txtllaveb,'r', encoding="ISO-8859-1") # leer archivo que contiene la llave de b
	llaveb=llaveb.read()
	llaveb=int(llaveb)

	
	generador=open(args.txtgenerador,'r', encoding="ISO-8859-1") # leer archivo que contiene la generador
	generador=generador.read()
	generador=int(generador)
	

	mensaje=open(args.texto,'r',encoding="ISO-8859-1") # leer archivo que contiene el texto plano
	mensaje=mensaje.read()
	mensaje=int(mensaje)

	primo=open(args.txtprimo,'r', encoding="ISO-8859-1") # leer archivo que contiene la primo
	primo=primo.read()
	primo=int(primo)

	llavepublic=open(args.txtpublica,'r', encoding="ISO-8859-1") # leer archivo que contiene la llave publica
	llavepublic=llavepublic.read()
	llavepublic=int(llavepublic)


	#formulas para sacar Y1 y Y2
	
	y1 = (generador**llaveb)%primo

	

	y2 = ((llavepublic**llaveb)*mensaje)%primo


	

	f = open ('y1.txt',"w", encoding="ISO-8859-1")
	f.write(str((y1)))
	f.close()

	f = open ('y2.txt',"w", encoding="ISO-8859-1")
	f.write(str((y2)))
	f.close()


	
	tiempo_final = time()			# funcion de calculo de tiempo final
	tiempo_total = tiempo_final - tiempo_inicial   #Calculo el tiempo total de ejecucion
	print("tiempo_total: ", tiempo_total)

if args.gama == True and args.gm == True:

	yuno=open(args.txty1,'r') # leer archivo que contiene el texto plano
	yuno=yuno.read()
	yuno=int(yuno)

	ydos=open(args.txty2,'r') # leer archivo que contiene la primo
	ydos=ydos.read()
	ydos=int(ydos)

	primo=open(args.txtprimo,'r') # leer archivo que contiene la primo
	primo=primo.read()
	primo=int(primo)

	calvea=open(args.txtpriva,'r') # leer archivo que contiene la llave de a
	calvea=calvea.read()
	calvea=int(calvea)

	#Formula para desencriptar

	mensajedec=((yuno**(primo-1-calvea))*ydos)%primo
	mensajedec=str(mensajedec)	


	
	cripto = open("mesaje.dec", "w", encoding="utf-8")
	cripto.write(mensajedec)

if args.gama == True and args.hash == True:

	texto=open(args.texto,'r') # leer archivo que contiene el mensaje decodificado
	texto=texto.read()
	texto=int(texto)
	texto=str(texto)

	filename = '/root/Downloads/' + args.texto
	hasher = hashlib.md5()
	with open(filename,"rb") as open_file:
		content = open_file.read()
		hasher.update(content)
	print ("Hash = ", hasher.hexdigest())


